import { cars } from "./../data/cars";
import { useState } from "react";

function CarsFilter() {
  let [carList, setCarList] = useState(cars);
  let [selectedBrand, setSelectedBrand] = useState("");

  function brandHandler(event) {
    setSelectedBrand(event.target.value);
  }

  let carsjsx = 
  carList
  .filter((car)=>car.name.toLowerCase().includes(selectedBrand.toLowerCase()))
  .map((car, index) => {
    return (
      <div className="border shadow p-2 m-2 car" key={index}>
        <div>{car.name}</div>
        <div>{car.release_year}</div>
        <div>{car.price}</div>
        <img src={car.url} alt={car.name} className="w-100" />
      </div>
    );
  });

  return (
    <>
      <form>
        {/* brand filter */}
        <h6>Filter by brand:</h6>

        <select
          name="brand-input"
          id="brand-input"
          value={selectedBrand}
          onChange={brandHandler}
        >
          <option value="">All</option>
          <option value="BMW">BMW</option>
          <option value="Audi">Audi</option>
          <option value="VW">VW</option>
        </select>
      </form>

      {/* for testing purpoises */}
      <div>{selectedBrand}</div>
      <div className="d-flex flex-wrap">{carsjsx}</div>
    </>
  );
}

export default CarsFilter;
