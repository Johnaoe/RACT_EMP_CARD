import './App.css'
import CarsFilter from './components/CarsFilter'

function App() {


  return (
    <div className="App">
     <CarsFilter/>
    </div>
  )
}

export default App
