Empty react project template, with ESLint and Bootstrap, React Bootstrap installed.
