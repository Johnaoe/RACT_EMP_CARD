//  https://robohash.org/set_set4/bgset_bg1/1?size=200x200  kitas setas - katės

export const robots = [
  {
    id: 1,
    name: "Siddhant Sehgal",
    username: "Siddhu",
    email: "muffin@gmail.com",
    avatar: "https://robohash.org/set_set3/bgset_bg1/1?size=200x200",
    reserved: "true"
  },
  {
    id: 2,
    name: "Vanya Azad",
    username: "Vannu",
    email: "cupcake@gmail.com",
    avatar: "https://robohash.org/set_set3/bgset_bg1/2?size=200x200",
    reserved: "true"
  },
  {
    id: 3,
    name: "Siddharth Sehgal",
    username: "Siddharth",
    email: "ricky@gmail.com",
    avatar: "https://robohash.org/set_set3/bgset_bg1/3?size=200x200",
    reserved: "false"
  },
  {
    id: 4,
    name: "Harshit Sehgal",
    username: "gugglu",
    email: "harshit@gmail.com",
    avatar: "https://robohash.org/set_set3/bgset_bg1/4?size=200x200",
    reserved: "true"
  },
  {
    id: 5,
    name: "Hitakshi Sehgal",
    username: "Hitakshi",
    email: "hitakshi@gmail.com",
    avatar: "https://robohash.org/set_set3/bgset_bg1/5?size=200x200",
    reserved: "false"
  },
];
