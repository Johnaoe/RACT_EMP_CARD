import React from "react";
import Robots from "./components/Robots";

function App() {
  return (
    <div className="App">
      <Robots />
    </div>
  );
}

export default App;
